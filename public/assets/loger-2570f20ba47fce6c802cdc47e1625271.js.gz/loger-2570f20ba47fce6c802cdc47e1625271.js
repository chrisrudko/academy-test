(function() {
  $(document).ready(function() {
    return alert("whatap");
  });

}).call(this);
