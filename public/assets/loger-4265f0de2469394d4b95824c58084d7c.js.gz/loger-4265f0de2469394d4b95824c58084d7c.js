(function() {
  $(document).ready(function() {
    return console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  });

}).call(this);
