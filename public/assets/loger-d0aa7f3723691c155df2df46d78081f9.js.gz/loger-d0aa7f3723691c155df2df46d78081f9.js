(function() {
  jQuery(function() {
    return alert($('#ui').data('user'));
  });

}).call(this);
