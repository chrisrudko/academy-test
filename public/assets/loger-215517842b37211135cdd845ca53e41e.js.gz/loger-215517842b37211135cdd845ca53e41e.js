(function() {
  $(document).ready(function() {
    return alert("asdgag");
  });

}).call(this);
