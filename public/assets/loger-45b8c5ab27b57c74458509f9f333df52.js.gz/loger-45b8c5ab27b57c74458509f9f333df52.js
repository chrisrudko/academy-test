(function() {
  $(document).ready(function() {
    return alert($('#ui').data('user'));
  });

}).call(this);
